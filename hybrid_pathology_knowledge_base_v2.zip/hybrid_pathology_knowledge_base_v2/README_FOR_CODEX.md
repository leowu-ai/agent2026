# Hybrid Pathology Knowledge Base v2

This ZIP extends the v1 knowledge base for the BRCA WSI-VQA hierarchical agent. The design goal is to improve **evidence-aware reasoning when direct patient-specific evidence is weak or missing**, without introducing a case-answer archive or held-out data leakage.

## What changed from v1

The v1 model/tool priors are preserved. `tool_semantics.jsonl`, `model_relations.jsonl`, and `program_gene_candidates.jsonl` remain byte-identical to v1.

The core files used by the current `KnowledgeRAG` loader were expanded:

- `pathology_concepts.jsonl`: 54 -> 65 concepts. Added explicit concepts for surgical margins, regional nodes, treatment/procedure metadata, report/test metadata, assay-specific quantitative results, patient clinical metadata, laterality/location, multifocality, gross specimen metadata, and evidence-aware option semantics. Existing stage, size, grade, ER/PR, and HER2 concepts were tightened with current guideline constraints.
- `evidence_rules.jsonl`: 10 -> 22 rules. Added evidence hierarchy, uncertainty semantics, units, margin context, TNM component consistency, nodal scope, multifocality scope, report/procedure metadata, biomarker granularity, Nottingham consistency, and composite-option preservation.

Supplemental v2 files are also included:

- `evidence_limitations_v2.jsonl`: explicit recoverability / proxy / invalid-inference policies for common evidence-insufficient targets.
- `proxy_evidence_rules_v2.jsonl`: safe ways to use weak visual or logical proxies without pretending they are measurements.
- `forced_choice_reasoning_v2.jsonl`: option-elimination policies for mandatory MCQ answering.
- `reasoning_examples_v2.jsonl`: synthetic/generic examples; no case IDs and no held-out answers.
- `train_pattern_summary_v2.json`: train-only question/choice semantic inventory. It contains no answer frequencies and no case IDs.
- `build_provenance.json` and `leakage_audit.json`: provenance and leakage safeguards.

## Intended agent use

```text
Question + Choices
       ↓
Phenotype-aware Router
       ↓
Phenotype / Morphology evidence
       ↓
Multi-scale G2P (4096 / 2048 / 1024)
       ↓
Knowledge RAG
       ↓
Evidence Verifier
       ├── sufficient → Final Fusion
       └── insufficient → hierarchical visual search → Patho-R1 → Program/Gene
                                      ↓
                                 Working Memory
                                      ↓
                                 Final Fusion
                                      ↓
                                  MCQ answer
```

The knowledge base does **not** choose an answer by training-case similarity. It should help the verifier/fusion model distinguish:

1. direct patient-specific evidence;
2. validated structured phenotype evidence for the intended target;
3. legitimate visual proxy evidence;
4. generic guideline/domain constraints;
5. unresolved patient-specific facts.

If the evidence is exhausted, the agent may still be required to choose an MCQ option, but it must not invent a measurement, assay result, treatment history, or report fact.

## Key v2 reasoning principles

- Exact tumor size is not derived from crop pixels. Whole-slide extent is at most a coarse proxy unless calibrated case-level measurement context exists.
- A tissue edge is not a surgical margin unless it is verified as an inked/oriented margin.
- TNM is decomposed into T/N/M; do not map grade directly to stage or invent missing N/M components.
- Nottingham grade uses tubule formation, nuclear pleomorphism, and mitotic count; score bands are 3-5 -> G1, 6-7 -> G2, 8-9 -> G3. Categorical grade does not identify an exact score within a band.
- ER/PR/HER2 categorical WSI surrogates are not measured IHC percentages or scores.
- HER2 IHC 2+ is equivocal and requires reflex ISH or a new validated HER2 test; it is not synonymous with amplification.
- Failure to observe a second focus under incomplete sampling does not prove unifocal disease.
- `no/negative` is not equivalent to `not mentioned/not provided/unknown`.
- Generic guidelines answer generic workflow questions, not patient-specific questions about what was actually performed.
- Never use train answer frequency, answer-position frequency, or nearest-neighbor train-case answers.

## Train-split usage and leakage boundary

`WsiVQA_train.json` was used only to inventory **recurring question/choice semantics** so that the KB covers benchmark-relevant categories. The build logic intentionally ignores the `Answer` and `Id` fields for that inventory. The v2 KB contains no TCGA case IDs, no train answer distributions, no validation/test records, and no case-retrieval index.

## Compatibility

The existing v1 `KnowledgeRAG` loader can immediately consume the enriched `pathology_concepts.jsonl` and `evidence_rules.jsonl` because the required core filenames and manifest count keys are preserved.

To make full use of the supplemental v2 files, a later code change can expose matched `evidence_limitations`, `proxy_rules`, `forced_choice_rules`, and `reasoning_examples` to the Verifier and Final Fusion. That code change should remain deterministic and should never retrieve examples by case ID or answer similarity.
