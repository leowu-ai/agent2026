# Hybrid Pathology Knowledge Base v1

This directory is the **knowledge content** for the WSI VQA Agent.

The knowledge content has already been prepared. Codex should implement the code that loads, retrieves, and uses it.

## What is inside

- `pathology_concepts.jsonl`
  - generic breast pathology knowledge;
  - benign and malignant morphology;
  - pathology evidence requirements;
  - candidate phenotype/program/gene support;
  - scale hints for 4096 → 2048 → 1024 evidence acquisition.

- `tool_semantics.jsonl`
  - semantics and limitations for the 17 current phenotype targets.

- `evidence_rules.jsonl`
  - rules for direct vs supportive evidence;
  - coarse-to-fine visual escalation;
  - assay-specific stop rules;
  - graph-constrained program/gene escalation.

- `model_relations.jsonl`
  - generated from the committed 1024/2048/4096 `R_program_to_phenotype.csv` matrices;
  - contains **all 22 program relations for every one of the 17 phenotype fields**;
  - each relation contains per-scale values, mean, standard deviation, cross-scale consensus, and graph score.

- `program_gene_candidates.jsonl`
  - representative program→gene candidate lists for semantic retrieval;
  - **not** a replacement for `H_gene_to_program.csv`;
  - Codex must intersect candidate genes with the actual H matrix before invoking a gene-level tool.

- `sources.json`
  - source metadata for pathology knowledge.

- `manifest.json`
  - file manifest and authoritative runtime graph paths.

## Critical interpretation

`model_relations.jsonl` contains **model-internal learned associations**.

Do not call these causal biological relations.

Gene/program evidence is WSI-derived model evidence and must never be represented as:

- measured RNA;
- mutation result;
- protein measurement;
- IHC result;
- FISH/ISH result;
- gene amplification;
- copy number.

## Intended Agent flow

```text
Question
  ↓
Knowledge RAG
  ↓
Planner / Working Memory
  ↓
4096 evidence
  ↓
Verifier
  ├── sufficient → Fusion / answer
  └── insufficient
        ↓
      2048
        ↓
      Verifier
        ↓
      1024
        ↓
      Verifier
        ├── sufficient → Fusion / answer
        └── molecular support useful
              ↓
       stable phenotype→program candidates
              ↓
       validate program→gene membership in H
              ↓
       program/gene attention evidence
              ↓
       update memory → verify → answer
```

## What Codex should implement

Codex should create a loader/retriever around these files. The KB itself should be treated as read-only content.

Recommended retrieval result:

```json
{
  "matched_concepts": [],
  "direct_tools": [],
  "supportive_tools": [],
  "scale_strategy": [],
  "candidate_programs": [],
  "candidate_genes": [],
  "limitations": [],
  "evidence_rules": []
}
```

Do not let the RAG directly choose the final MCQ option.

## No benchmark leakage

This KB was built from generic pathology knowledge and the existing model priors.

It was **not** built from WsiVQA reference answers or Gold answerability labels.

Do not add case-ID-specific rules or test-answer-derived knowledge during integration.

## Suggested first integration milestone

1. Load all JSONL files.
2. Retrieve concepts from question + choices.
3. Return direct/supportive evidence separately.
4. Expand matched phenotype through `model_relations.jsonl`.
5. Before gene invocation, intersect candidate genes with the actual `H_gene_to_program.csv`.
6. Keep the existing formal VQA pipeline unchanged behind a disabled-by-default flag until unit tests pass.
